# Enquête sur la connaissance du genre – Ministères sectoriels (RDC)

Mini-portail **statique** (HTML/CSS/JS) prêt pour **GitHub Pages** afin de visualiser les résultats d’une enquête KoboToolbox sur la connaissance et l’intégration du genre dans les ministères sectoriels.

## Pages
- **Accueil** : `index.html` (KPIs + graphiques)
- **Analyse** : `analyse.html` (tendances + obstacles)
- **Ministères** : `ministeres.html` (comparaison + filtres + tableau)
- **Recommandations** : `recommandations.html`

## Données
Les visualisations lisent des fichiers JSON dans `data/` :
- `summary.json`
- `ministeres.json`
- `indicateurs.json`
- `recommandations.json`

➡️ Remplacez ces fichiers par vos résultats réels.

## ETL (CSV Kobo → JSON)
Script : `scripts/kobo_to_json.py`

1) Exportez Kobo en CSV  
2) Placez le fichier ici : `data/raw/submissions.csv` (créez le dossier `data/raw`)  
3) Exécutez :
```bash
python scripts/kobo_to_json.py data/raw/submissions.csv
```

## Publication GitHub Pages
1) Pousser le dépôt sur GitHub  
2) **Settings → Pages** → Source : `Deploy from a branch` → `main` / `(root)`  
3) Ouvrir l’URL générée

---
Prototype UN Women / GiHA – à adapter.
