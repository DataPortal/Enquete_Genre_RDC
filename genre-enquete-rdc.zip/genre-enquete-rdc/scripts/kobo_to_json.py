import sys, json, os
import pandas as pd


"""
kobo_to_json.py
Convertit un export Kobo (CSV) en JSON agrégés pour le portail.

À ADAPTER selon votre CSV (noms de colonnes).
Usage:
  python scripts/kobo_to_json.py data/raw/submissions.csv
"""

YES = {"oui","yes","y","true","1","vrai"}

def norm(s):
    if pd.isna(s): return ""
    return str(s).strip()

def is_yes(v):
    return norm(v).lower() in YES

def pct(num, den):
    return round((num/den)*100) if den else 0

def dist(series):
    s = series.dropna().map(norm)
    out = s.value_counts().reset_index()
    out.columns = ["label","value"]
    return out.to_dict(orient="records")

def main(csv_path):
    df = pd.read_csv(csv_path)

    # --- ADAPTER ICI ---
    col_min = "ministere"
    col_sex = "sexe"
    col_fct = "fonction"
    col_score = "score_connaissance"
    col_forme = "a_ete_forme_genre"     # oui/non
    col_pf = "point_focal_genre"        # oui/non
    col_int = "integration_genre"       # oui/non

    missing = [c for c in [col_min, col_sex, col_fct] if c not in df.columns]
    if missing:
        raise SystemExit(f"Colonnes manquantes: {missing}. Ajustez les noms dans le script.")

    if col_score not in df.columns:
        df[col_score] = 0

    total = len(df)
    pourc_formes = pct(df[col_forme].apply(is_yes).sum(), total) if col_forme in df.columns else 0
    score_moy = int(round(pd.to_numeric(df[col_score], errors="coerce").fillna(0).mean())) if total else 0

    ministeres_pf = 0
    integration = 0
    if col_pf in df.columns:
        by_min = df.groupby(col_min)[col_pf].apply(lambda s: any(is_yes(x) for x in s))
        ministeres_pf = pct(int(by_min.sum()), len(by_min))
    if col_int in df.columns:
        by_min2 = df.groupby(col_min)[col_int].apply(lambda s: any(is_yes(x) for x in s))
        integration = pct(int(by_min2.sum()), len(by_min2))

    summary = {
        "total_repondants": int(total),
        "pourcentage_formes_genre": int(pourc_formes),
        "ministeres_avec_point_focal": int(ministeres_pf),
        "integration_politiques": int(integration),
        "score_moyen_connaissance": int(score_moy),
        "periode_collecte": "",
        "note_methodo": "Export KoboToolbox (CSV)"
    }

    # Agrégats ministère
    m = df.groupby(col_min).agg(
        formes_genre=(col_forme, lambda s: pct(sum(is_yes(x) for x in s), len(s))) if col_forme in df.columns else (col_min, "size"),
        point_focal=(col_pf, lambda s: any(is_yes(x) for x in s)) if col_pf in df.columns else (col_min, lambda s: False),
        integration=(col_int, lambda s: pct(sum(is_yes(x) for x in s), len(s))) if col_int in df.columns else (col_min, lambda s: 0),
        score=(col_score, lambda s: int(round(pd.to_numeric(pd.Series(s), errors="coerce").fillna(0).mean())))
    ).reset_index().rename(columns={col_min:"ministere"}).to_dict(orient="records")

    # Distributions
    sexe = dist(df[col_sex]) if col_sex in df.columns else []
    fonction = dist(df[col_fct]) if col_fct in df.columns else []

    # Score bins
    scores = pd.to_numeric(df[col_score], errors="coerce").fillna(0)
    bins = [0,20,40,60,80,100]
    labels = ["0-20","21-40","41-60","61-80","81-100"]
    cats = pd.cut(scores, bins=bins, labels=labels, include_lowest=True, right=True)
    score_bins = cats.value_counts().reindex(labels, fill_value=0).reset_index()
    score_bins.columns = ["label","value"]
    score_bins = score_bins.to_dict(orient="records")

    # Obstacles: colonnes obstacles_*
    obs_cols = [c for c in df.columns if c.lower().startswith("obstacles_")]
    obstacles = []
    for c in obs_cols:
        obstacles.append({"label": c.replace("obstacles_","").replace("_"," ").strip().title(),
                          "value": int(df[c].apply(is_yes).sum())})
    obstacles = sorted(obstacles, key=lambda x: x["value"], reverse=True)

    indicateurs = {"sexe": sexe, "fonction": fonction, "score_bins": score_bins, "obstacles": obstacles}

    out_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    with open(os.path.join(out_dir, "ministeres.json"), "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)
    with open(os.path.join(out_dir, "indicateurs.json"), "w", encoding="utf-8") as f:
        json.dump(indicateurs, f, ensure_ascii=False, indent=2)

    print("OK: JSON mis à jour dans data/")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("Usage: python scripts/kobo_to_json.py data/raw/submissions.csv")
    main(sys.argv[1])
