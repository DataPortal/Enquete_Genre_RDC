document.addEventListener("DOMContentLoaded", async ()=>{
  setActiveNav();
  const summary = await loadJSON("data/summary.json");
  setText("kpiRespondants", fmtNum(summary.total_repondants));
  setText("kpiFormes", fmtPct(summary.pourcentage_formes_genre));
  setText("kpiPF", fmtPct(summary.ministeres_avec_point_focal));
  setText("kpiIntegr", fmtPct(summary.integration_politiques));
  setText("kpiScore", fmtNum(summary.score_moyen_connaissance));
  setText("periodeCollecte", summary.periode_collecte || "—");
  setText("noteMethodo", summary.note_methodo || "—");

  const indicateurs = await loadJSON("data/indicateurs.json");
  drawBarChart(document.getElementById("chartScore"),
               indicateurs.score_bins.map(x=>x.label),
               indicateurs.score_bins.map(x=>x.value));
  drawDoughnut(document.getElementById("chartSexe"), indicateurs.sexe, {centerText:"Profil"});
});
