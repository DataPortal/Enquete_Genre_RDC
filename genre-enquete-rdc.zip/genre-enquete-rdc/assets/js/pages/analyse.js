document.addEventListener("DOMContentLoaded", async ()=>{
  setActiveNav();
  const indicateurs = await loadJSON("data/indicateurs.json");
  drawDoughnut(document.getElementById("chartFonction"), indicateurs.fonction, {centerText:"Fonction"});
  drawBarChart(document.getElementById("chartObstacles"),
               indicateurs.obstacles.map(o=>o.label),
               indicateurs.obstacles.map(o=>o.value));
  const summary = await loadJSON("data/summary.json");
  setText("kpiScore", fmtNum(summary.score_moyen_connaissance));
});
