let _ministeres = [];
let _filtered = [];

function renderTable(rows){
  const tbody = document.getElementById("tblBody");
  tbody.innerHTML = "";
  rows.forEach(r=>{
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${r.ministere}</td>
      <td>${fmtPct(r.formes_genre)}</td>
      <td>${r.point_focal ? '<span class="pill"><span class="mini"></span>Oui</span>' :
        '<span class="pill"><span class="mini" style="background: var(--uw-orange)"></span>Non</span>'}</td>
      <td>${fmtPct(r.integration)}</td>
      <td><strong>${fmtNum(r.score)}</strong></td>
    `;
    tbody.appendChild(tr);
  });
}

function applyFilters(){
  const q = (document.getElementById("qMinistere").value || "").toLowerCase().trim();
  const pf = document.getElementById("fPointFocal").value;

  _filtered = _ministeres.filter(r=>{
    const okName = !q || r.ministere.toLowerCase().includes(q);
    const okPf = (pf === "all") || (pf === "yes" && r.point_focal) || (pf === "no" && !r.point_focal);
    return okName && okPf;
  });

  renderTable(_filtered);

  const top = [..._filtered].sort((a,b)=>b.score-a.score).slice(0,10);
  drawBarChart(document.getElementById("chartMinisteres"),
               top.map(x=>x.ministere),
               top.map(x=>x.score));
  setText("countMinisteres", fmtNum(_filtered.length));
}

document.addEventListener("DOMContentLoaded", async ()=>{
  setActiveNav();
  _ministeres = await loadJSON("data/ministeres.json");
  document.getElementById("qMinistere").addEventListener("input", applyFilters);
  document.getElementById("fPointFocal").addEventListener("change", applyFilters);
  applyFilters();
});
